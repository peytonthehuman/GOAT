
<?php
/*
Template Name: MyTemplateClassreadcsv
*/

	// Call repeatedly
	// Will return 0 when it reaches the end of the CSV files
	// Otherwise will return an array of values from CSV with named keys:
	// Array Structure:
	//		"Media_Id"
	//		"Title"
	//		"Date_Released"
	//		"Media_Type"
	//		"Secondary" ->
	//			// If Media_type == 1
	//			"Author"
	//			"Num_Of_Pages"
	//			// If Media_Type == 2
	//			"Duration"
	//			"Producers"
	//			"Actors"
	//			// If Media_Type == 3
	//			"Console"
	//		"Genres"
	//			0, 1, 2
	
	    set_time_limit(500);


        for($i = 5000; $i <6999; $i++)
        {
        //   print_r(readEntryFromCSVs($i));
           
           
           //media id
                
           
                   
		  $m = readEntryFromCSVs($i);
                    //var for Movie
        
		 $Title = $m["Title"];
		 $Media_Id = $m["Media_Id"];
		 
		 
		// print($m["Media_type"]);
		// print($m["Genres"][0]);
		 
		 /*
		 $Console = $m["Console"];
	   	$Date_Released = $m["Date_Released"];
		 
	 	// print($m["Media_Type"]);
	        
	        print($Title);
	        print($m["Media_type"]);
		    print($Console);
           print($m["Genres"][0]);
           */
           
		   //insert everything into media table
		   //books
		   if($m["Media_Type"] == 1)
		   {
			require_once 'connectdb.php';
			//do a loop to see how many genres
			$numOfGenres = 0;
			foreach($m["Genres"] as $g )
			{
				$numOfGenres += 1;
			}

			//var for books
			$Title = $m["Title"];
			$Media_Id = $m["Media_Id"];
			$Author = $m["Author"];
			$Num_Of_Pages = $m["Num_Of_Pages"];
			$Date_Released = $m["Date_Released"];
			
			print($m["Media_Type"]);
			print($Author);
           print($m["Genres"][0]);
           print($Num_Of_Pages);
		   print("<br>");
			
			//insert into media table
			$sql1 = "INSERT INTO Media(Title,Date_Released,Media_Type,Picture_Path,num_of_generes,Media_Id)	
			VALUES('$Title','$Date_Released',1,'picPath',$numOfGenres,'$Media_Id')";		  

			mysqli_query($con,$sql1);


			//insert into book table as well
			$sql2 = "INSERT INTO Book(Author,Num_Of_Pages,Media_Id) 
			VALUES ('$Author',0,'$Media_Id')";		  

			mysqli_query($con,$sql2);




			

			$numOfGenres = 0;
		   }
		   else if($m["Media_Type"] == 2)
		   {
			require_once 'connectdb.php';
			//do a loop to see how many genres
		

			//var for Movie
			$Title = $m["Title"];
			$Media_Id = $m["Media_Id"];
			$Duration = $m["Duration"];
			$Producers = $m["Producers"];
			$Actors = $m["Actors"];
			$Date_Released = $m["Date_Released"];

         	$numOfGenres = 0;
			foreach($m["Genres"] as $g )
			{
				$numOfGenres += 1;
				print_r($g);
		    	$sqlG = "INSERT INTO Genre(Genre,Media_Id) 
		    	VALUES ('$g','$Media_Id')";		  

			    mysqli_query($con,$sqlG);

			}

			//insert into media table
			$sql3 = "INSERT INTO Media(Title,Date_Released,Media_Type,Picture_Path,num_of_generes,Media_Id)	
			VALUES('$Title','$Date_Released',2,'picPath',$numOfGenres,'$Media_Id')";		  

			mysqli_query($con,$sql3);


			//insert into book table as well
			$sql4 = "INSERT INTO Movie(Duration,Producers,Actors,Media_Id) 
			VALUES ('$Duration','$Producers','$Actors','$Media_Id')";		  

			mysqli_query($con,$sql4);




			

			$numOfGenres = 0;


           
          
		}
		else if($m["Media_Type"] == 3)
		{
                    /*
		    
		 require_once 'connectdb.php';
		 //do a loop to see how many genres
		 $numOfGenres = 0;
		 foreach($m["Genres"] as $g )
		 {
			 $numOfGenres += 1;
		 }

		 //var for Movie
		 $Title = $m["Title"];
		 $Media_Id = $m["Media_Id"];
		 $Console = $m["Console"];
		 $Date_Released = $m["Date_Released"];
		 
                 print($m["Media_Type"]);
	         print($Console);
			
                 print($m["Genres"][0]);
           
		   print("<br>");


		 //insert into media table
		 $sql5 = "INSERT INTO Media(Title,Date_Released,Media_Type,Picture_Path,num_of_generes,Media_Id)	
		 VALUES('$Title','$Date_Released',3,'picPath',$numOfGenres,'$Media_Id')";		  

		 mysqli_query($con,$sql5);


		 //insert into book table as well
		 $sql6 = "INSERT INTO Video_Game(Console,Media_Id) 
		 VALUES ('$Console','$Media_Id')";		  

		 mysqli_query($con,$sql6);

*/


		 

		// $numOfGenres = 0;


		
	   
	 }
                   
                   
 
	}



	function readEntryFromCSVs($index) {
            
           
		$dataPath = "wp-content/themes/mins/";
		$media = fopen($dataPath . "media.csv", 'r');
		$genre = fopen($dataPath . "genre.csv", 'r');
		$movie = fopen($dataPath . "movie.csv", 'r');
		$book  = fopen($dataPath . "book.csv", 'r');
		$vgame = fopen($dataPath . "vgame.csv", 'r');
		
		for($i = 0; $i < $index; $i ++) {
			fgets($media);
		}
		
		$entry = fgetcsv($media, 0, '|');
		
		$retVal = array();
		
		$retVal["Media_Id"] = $entry[1];
		$retVal["Title"] = $entry[2];
		$retVal["Date_Released"] = $entry[3];
		$retVal["Media_Type"] = $entry[4];
		
		// 1 = books
		// 2 = movies
		// 3 = vgames
		if($entry[4] == 1) {
			// Fix Media_Id
			$indEntry = seekToIndex($book, $index);
			if($indEntry == false) {
				throw new Exception("Entry " . $index . " not found in book database.");
			}
			$retVal["Secondary"]["Author"] = $indEntry[2];
			$retVal["Secondary"]["Num_Of_Pages"] = $indEntry[3];
		} else if($entry[4] == 2) {
			$indEntry = seekToIndex($movie, $index, 25); // will need to fix
			if($indEntry == false) {
				throw new Exception("Entry " . $index . " not found in movie database.");
			}
			$retVal["Secondary"]["Duration"] = $indEntry[2];
			$retVal["Secondary"]["Producers"] = $indEntry[3];
			$retVal["Secondary"]["Actors"] = $indEntry[4];
		} else if($entry[4] == 3) {
			$indEntry = seekToIndex($vgame, $index, 30); // Will need to fix
			if($indEntry == false) {
				throw new Exception("Entry " . $index . " not found in vgame database.");
			}
			$retVal["Secondary"]["Console"] = $indEntry[2];
		}
		
		$line = seekToIndex($genre, $index);
		if($line == false) {
			throw new Exception("Entry " . $index . " not found in genre table.");
		} else {
			$genreIdx = 0;
			do {
				$retVal["Genres"][$genreIdx] = $line[2];
				$line = fgetcsv($genre, 90, '|');
				$genreIdx++;
			} while($line[0] == $index);
		}
		
		fclose($media);
		fclose($genre);
		fclose($movie);
		fclose($book);
		fclose($vgame);
		
		
		
		return $retVal;
	}
	
	function seekToIndex($file, $index, $length = 0, $col = 0) {
		while(true) {
			$array = fgetcsv($file, $length, '|');
			if($array == false) {
				return false;
			} else if($array[$col] == $index) {
				return $array;
			}
		}
	}
?>