<?php
/*
Template Name: ClassConnect
*/
$host = "localhost";
$user_name = "VisitClass";
$user_password = "VisitClass";
$db_name = "Media_Recommender";

$con = mysqli_connect($host,$user_name,$user_password,$db_name);

?>