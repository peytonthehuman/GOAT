<?php
/*
Template Name: MyTemplateGetMovies
*/
if($_SERVER['REQUEST_METHOD'] == 'POST')
{


  $pos= $_POST['pos'];
  $posi = (int)$pos;
  $posi = 9000;
  
  require_once 'connectdb.php';

  $sql = "SELECT * FROM Media WHERE Media_Type = 2";

  $response = mysqli_query($con,$sql);

 $result = array();
 $result['movie'] = array();


 $stmt = $con->prepare($sql);
 $stmt->execute();


$i = 9700;
$j = $i;

 while($stmt->fetch() && $i != 10000)
   {
      
      for($j; $j < (9700);$j++)
      {
        
         $row = mysqli_fetch_assoc($response);
      }
      
     //get all info and push it
      $row = mysqli_fetch_assoc($response);

      $index['Title'] = $row['Title'];
      
	  $index['Date_Released'] = $row['Date_Released'];

      $index['num_of_generes'] = $row['num_of_generes'];
      $index['Media_Id'] = $row['Media_Id'];

      $index['num_of_generes'] = strval($index['num_of_generes']);


     array_push($result['movie'],$index);
     $i++;


   }

 $result['success'] = "1";
 $result['message'] = "success";

 echo json_encode($result);
 mysqli_close($con);

}





 ?>
