<?php
/*
Template Name: MyTemplateGetMoviesFromUser
*/
if($_SERVER['REQUEST_METHOD'] == 'POST')
{


  $user_id= $_POST['user_id'];
  $user_id = (int)$user_id;

  require_once 'connectdb.php';

  $sql = "SELECT * FROM Saved_Media_List WHERE User_Id = $user_id";

  $response = mysqli_query($con,$sql);

 $result = array();
 $result['movieid'] = array();


 $stmt = $con->prepare($sql);
 $stmt->execute();


//get all movie ids from user
 while($stmt->fetch())
   {

      //get all info and push it
      $row = mysqli_fetch_assoc($response);

      $index['Media_Id'] = $row['Media_Id'];


      array_push($result['movieid'],$index);
        
      
      


   }
  



//get all the movies
  $results['movie'] = array();

for($i = 0;$i < sizeof($result['movieid']);$i++)
{
   $id = $result['movieid'][$i]['Media_Id'];
  
  
    require_once 'connectdb.php';
   
  $sql1 = "SELECT * FROM Media WHERE Media_Id = '$id'";
   
  $responsee = mysqli_query($con,$sql1);



  if(mysqli_num_rows($responsee) === 1)
   {
      //get all info and push it
      $roww = mysqli_fetch_assoc($responsee);
      $indexm['Title'] = $roww['Title'];
      
      $indexm['Date_Released'] = $roww['Date_Released'];

      $indexm['num_of_generes'] = $roww['num_of_generes'];
      $indexm['Media_Id'] = $roww['Media_Id'];

      $indexm['num_of_generes'] = strval($indexm['num_of_generes']);

      array_push($results['movie'],$indexm);


   }


}



$results['success'] = "1";
$results['message'] = "success";

echo json_encode($results);
mysqli_close($con);


}
 ?>
