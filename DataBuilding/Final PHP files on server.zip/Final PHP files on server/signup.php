<?php
/*
Template Name: ClassSignUp
*/
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
   $Username= $_POST['username'];
   $Password = $_POST['password'];
   $Email= $_POST['email'];
   $FirstName= $_POST['firstName'];
   $LastName= $_POST['lastName'];
   $Birthday = $_POST['birthday'];

   $Password = password_hash($Password,PASSWORD_DEFAULT);


   //check to see if username is already taken
   require_once 'connectdb.php';

   $sql = "SELECT Username FROM User WHERE Username = '$Username'";
 
   $response = mysqli_query($con,$sql);
 
   $result = array();
   $result['signup'] = array();
 
  
   if(mysqli_num_rows($response) === 1)
   {
       //send back username is already taken
       $result['success'] = "0";
       $result['message'] = "error";
 
 
       echo json_encode($result);
       mysqli_close($con);
 

   }
   else
   {

      //let user sign up
      require_once 'connectdb.php';

      $sql = "INSERT INTO User(User_Id,Username,Password,Picture_Path,Email,Birthday,LastName,FirstName) VALUES (0,'$Username','$Password','picPath','$Email','$Birthday','$LastName','$FirstName')";
      mysqli_query($con,$sql);

      $result['success'] = "1";
      $result['message'] = "success";

      echo json_encode($result);
      mysqli_close($con);

   }



  }


 ?>