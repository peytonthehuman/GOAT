<?php
/*
Template Name: MyTemplateClassLogin
*/
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
  $login_Username = $_POST['username'];
  $login_Password = $_POST['password'];
  $loginId;

  require_once 'connectdb.php';

  $sql = "SELECT * FROM User WHERE Username = '$login_Username'";

  $response = mysqli_query($con,$sql);

  $result = array();
  $result['login'] = array();

 
  if(mysqli_num_rows($response) === 1)
  {
    $row = mysqli_fetch_assoc($response);

    if(password_verify($login_Password,$row['Password']))
    {
    //get all info and push it
    
      $index['User_Id'] = $row['User_Id'];
	    $index['Username'] = $row['Username'];
	    //$index['Password'] = $row['Password'];
      $index['Picture_Path'] = $row['Picture_Path'];
      $index['Email'] = $row['Email'];
	    $index['Birthday'] = $row['Birthday'];
	    $index['LastName'] = $row['LastName'];
      $index['FirstName'] = $row['FirstName'];

      $loginId = $row['User_id'];

      /*
      //search for saved media and rated media in DB with that user id.
      array_push($result['login'],$index);
      $sql = "SELECT * FROM User WHERE Username = '$login_Username'";

      $response = mysqli_query($con,$sql);
      */
      array_push($result['login'],$index);

      $result['success'] = "1";
      $result['message'] = "success";


      echo json_encode($result);
      mysqli_close($con);

    }
    else
    {
      $result['success'] = "0";
      $result['message'] = "error";

      echo json_encode($result);
      mysqli_close($con);

    }



  }
  else 
  {
    $result['success'] = "0";
    $result['message'] = "error";

    echo json_encode($result);
    mysqli_close($con);
  }


}





 ?>