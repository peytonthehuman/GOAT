
<?php
/*
Template Name: Classputinuser
*/
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
   $media_id= $_POST['media_id'];
   $user_id = $_POST['user_id'];
   $user_id = (int)$user_id;


   //check to see if username is already taken
   require_once 'connectdb.php';

   $sql = "INSERT INTO Saved_Media_List(User_Id,Media_Id) VALUES ($user_id,'$media_id')";


    $result = array();
    $result['success'] = array();

     if(mysqli_query($con,$sql))
     {

         $result['success'] = "1";
         $result['message'] = "success";

         echo json_encode($result);
         mysqli_close($con);

       }
       else
       {
         $result['success'] = "0";
         $result['message'] = "error";

         echo json_encode($result);
         mysqli_close($con);


       }




  }


 ?>
